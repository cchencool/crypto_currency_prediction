# Here you can
# 1. import necessary python packages for your strategy
# 2. Load your own facility files containing functions, trained models, extra data, etc for later use
# 3. Set some global constants
# Note:
# 1. You should put your facility files in the same folder as this strategy.py file
# 2. When load files, ALWAYS use relative path such as "data/facility.pickle"
# DO NOT use absolute path such as "C:/Users/Peter/Documents/project/data/facility.pickle"
from auxiliary import generate_bar
import pandas as pd
from sklearn.externals import joblib
import statsmodels.api as sm
from statsmodels.tsa.api import VAR, DynamicVAR
import numpy as np

model = sm.load('var_model_3')
asset_index = [0, 1, 2 ,3]
bar_length = 60  # Number of minutes to generate next new bar

# Here is your main strategy function
# Note:
# 1. DO NOT modify the function parameters (time, data, etc.)
# 2. The strategy function AWAYS returns two things - position and memory:
# 2.1 position is a np.array (length 4) indicating your desired position of four crypto currencies next minute
# 2.2 memory is a class containing the information you want to save currently for future use


def handle_bar(counter,  # a counter for number of minute bars that have already been tested
               time,  # current time in string format such as "2018-07-30 00:30:00"
               data,  # data for current minute bar (in format 2)
               init_cash,  # your initial cash, a constant
               transaction,  # transaction ratio, a constant
               cash_balance,  # your cash balance at current minute
               crypto_balance,  # your crpyto currency balance at current minute
               total_balance,  # your total balance at current minute
               position_current,  # your position for 4 crypto currencies at this minute
               memory  # a class, containing the information you saved so far
               ):
    # Here you should explain the idea of your strategy briefly in the form of Python comment.
    # You can also attach facility files such as text & image & table in your team folder to illustrate your idea

    # The idea of my strategy:
    # Logistic regression with label = rising/falling signal. 

    # Pattern for long signal:
    # When the predicted signal is rising, we long 1 BTC at the next bar; otherwise we short 1 BTC at the next bar.

    # Pattern for short signal:
    # When the predicted probability of rising is low (i.e., lower than 0.45), we short 1 BTC at the next bar.

    # No controlling of the position is conducted in this strategy.

    # Get position of last minute
    position_new = position_current
    
    # Generate OHLC data for every 30 minutes
    if (counter == 0):
      memory.data_save = []
      for i in asset_index:
        #memory.data_save = np.zeros((bar_length, 5))#, dtype=np.float64)
        temp = pd.DataFrame(columns = ['close', 'high', 'low', 'open', 'volume'])
        memory.data_save.append(temp)
      memory.hourly = pd.DataFrame(columns = ['BCH', 'BTC', 'ETH', 'LTC'])

    if ((counter + 1) % bar_length == 0):
      bar = []
      for i in asset_index:
        memory.data_save[i].loc[bar_length - 1] = data[i]
        temp = generate_bar(memory.data_save[i]) # pandas dataframe
        bar.append(temp)
      open_ave = np.array([bar[0]['open_ave'].values[0], bar[1]['open_ave'].values[0], bar[2]['open_ave'].values[0], bar[3]['open_ave'].values[0] ])
      
      hourly_data = pd.DataFrame(data = [open_ave], columns = ['BCH', 'BTC', 'ETH', 'LTC'] )

      memory.hourly = pd.concat([memory.hourly, hourly_data], ignore_index = True )
      
      lag_order = model.k_ar      
      # predict
      
      if lag_order < len(memory.hourly.index):
        diff = np.log(memory.hourly).diff().dropna()
        X = diff.values[-lag_order:]
        pred = model.forecast(X, 2)
        #strategy
        baseline = 0
        for i in [0, 2, 3]:
          if (pred[0][i] > baseline and pred[1][i] > baseline): position_new[i] += 1
          if (pred[0][i] < (0-baseline)  and pred[1][i] < (0- baseline) ): position_new[i] -= 1

    else:
      for i in asset_index:
        memory.data_save[i].loc[(counter + 1) % bar_length - 1] = data[i]#####


    # End of strategy
    return position_new, memory
