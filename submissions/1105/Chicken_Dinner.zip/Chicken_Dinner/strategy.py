# Here you can
# 1. import necessary python packages for your strategy
# 2. Load your own facility files containing functions, trained models, extra data, etc for later use
# 3. Set some global constants
# Note:
# 1. You should put your facility files in the same folder as this strategy.py file
# 2. When load files, ALWAYS use relative path such as "data/facility.pickle"
# DO NOT use absolute path such as "C:/Users/Peter/Documents/project/data/facility.pickle"
from auxiliary import generate_bar
import pandas as pd
import pickle

# The models below are used for prediction of 4 currencies respectively. The model is based on Random Forest.
with open('model_BCH.pickle', 'rb') as f:
    model_BCH = pickle.load(f)

with open('model_BTC.pickle', 'rb') as f:
    model_BTC = pickle.load(f)

with open('model_ETH.pickle', 'rb') as f:
    model_ETH = pickle.load(f)

with open('model_LTC.pickle', 'rb') as f:
    model_LTC = pickle.load(f)

asset_index = list(range(4))  # consider all 4 currencies provided
asset_name = ['BCH', 'BTC', 'ETH', 'LTC']
bar_length = 60  # Number of minutes to generate next new bar

# Here is your main strategy function
# Note:
# 1. DO NOT modify the function parameters (time, data, etc.)
# 2. The strategy function AWAYS returns two things - position and memory:
# 2.1 position is a np.array (length 4) indicating your desired position of four crypto currencies next minute
# 2.2 memory is a class containing the information you want to save currently for future use

def handle_bar(counter,  # a counter for number of minute bars that have already been tested
               time,  # current time in string format such as "2018-07-30 00:30:00"
               data,  # data for current minute bar (in format 2)
               init_cash,  # your initial cash, a constant
               transaction,  # transaction ratio, a constant
               cash_balance,  # your cash balance at current minute
               crypto_balance,  # your crpyto currency balance at current minute
               total_balance,  # your total balance at current minute
               position_current,  # your position for 4 crypto currencies at this minute
               memory  # a class, containing the information you saved so far
               ):
    # Here you should explain the idea of your strategy briefly in the form of Python comment.
    # You can also attach facility files such as text & image & table in your team folder to illustrate your idea

    # The idea of my strategy:
    # Transfer original dataset into following format: calculate the rate of increasing and decreasing, the change of
    # volume with the unit of an hour. When rate is larger than 0.2%, we set it as 'up'. When rate is lower than 0.4%,
    # we set is as 'down', the others are 'middle'. As for volume, if the absolute change rate is larger than 201%, we
    # set it as sharp, while the rest are 'flat'. Based on all these categorical variables in past two hours, we utilize
    # random forest to predict the changing rate of price next hour. If the rate is 'up', we long. If the rate is 'down'
    # , we short. Otherwise, we hold.

    # We set a more strict boundary of cash balance to make sure that no suddenly stop will happen. The boundary is
    # 20000 USD.

    # Get position of last minute

    position_new = position_current
    if cash_balance < 20000:
        for i in asset_index:
            position_new[i] = 0
        return position_new, memory

    if (counter == 0):
        memory.data_save = []
        memory.data_cryp = []
        for i in asset_index:
            #memory.data_save = np.zeros((bar_length, 5))#, dtype=np.float64)
            memory.data_save.append(pd.DataFrame(columns = ['close', 'high', 'low', 'open', 'volume']))
            memory.data_cryp.append(pd.DataFrame(columns = ['close', 'high', 'low', 'open', 'volume']))
        memory.hourly = pd.DataFrame(columns = ['rate_BCH', 'dVolume_BCH', 'rate_BTC', 'dVolume_BTC',
                                                'rate_ETH', 'dVolume_ETH', 'rate_LTC', 'dVolume_LTC'])

    if ((counter + 1) % bar_length == 0):
        for i in asset_index:
            memory.data_save[i].loc[bar_length - 1] = data[i, ]
            line = generate_bar(memory.data_save[i])
            memory.data_cryp[i] = pd.concat((memory.data_cryp[i], line), axis=0)
            memory.data_cryp[i] = memory.data_cryp[i].reset_index(drop=True)

    else:
        for i in asset_index:
            memory.data_save[i].loc[(counter + 1) % bar_length - 1] = data[i,]

    df_cryp_sp = []
    for i in asset_index:
        df_cryp = memory.data_cryp[i].copy()
        if len(df_cryp)>1:

            df_cryp['rate'] = (df_cryp['close'] -df_cryp['open']) / df_cryp['open']
            volume = pd.DataFrame(df_cryp['volume'][0:len(df_cryp)-1], columns=['volume'])
            df_cryp = df_cryp.drop(0).reset_index(drop = True)
            df_cryp['dVolume'] = abs((df_cryp['volume'] - volume['volume']) / volume['volume'])
            df_cryp = df_cryp[['rate', 'dVolume']]
            rateName = 'rate_' + asset_name[i]
            dVolumeName = 'dVolume_' + asset_name[i]
            df_cryp.columns = [rateName, dVolumeName]
            df_cryp_sp.append(df_cryp)
            memory.data_cryp[i] = memory.data_cryp[i].drop(0).reset_index(drop=True)
    if df_cryp_sp:
        cryp_data = pd.DataFrame()
        for cryp in df_cryp_sp:
            cryp_data = pd.concat((cryp_data, cryp), axis=1)
        memory.hourly = pd.concat((memory.hourly, cryp_data), axis=0).reset_index(drop=True)

    if len(memory.hourly)>2:
        df_hourly = memory.hourly.copy()
        for name in asset_name:
            bins = [-1, -0.005, 0.01, 1]
            group_name = ['down', 'middle', 'up']
            predName = 'pred_' + name
            rateName = 'rate_' + name
            df_hourly[predName] = pd.cut(df_hourly[rateName], bins, labels=group_name)
            bins_volume = [0, 2.01, 100]
            group_volume_name = ['flat', 'sharp']
            dVolumeName = 'dVolume_' + name
            df_hourly[dVolumeName] = pd.cut(df_hourly[dVolumeName], bins_volume, labels=group_volume_name)
        df_hourly = df_hourly[
            ['pred_BCH', 'pred_BTC', 'pred_ETH', 'pred_LTC', 'dVolume_BCH', 'dVolume_BTC', 'dVolume_ETH',
             'dVolume_LTC']]
        df_cryp_t0 = pd.DataFrame(df_hourly.loc[0:len(memory.hourly) - 3])
        df_cryp_t0.columns = ['BCH_t0', 'BTC_t0', 'ETH_t0', 'LTC_t0', 'dV_BCH_t0', 'dV_BTC_t0', 'dV_ETH_t0',
                              'dV_LTC_t0']
        df_cryp_t0 = df_cryp_t0.reset_index(drop=True)
        df_cryp_t1 = pd.DataFrame(df_hourly.loc[1:len(memory.hourly) - 2])
        df_cryp_t1.columns = ['BCH_t1', 'BTC_t1', 'ETH_t1', 'LTC_t1', 'dV_BCH_t1', 'dV_BTC_t1', 'dV_ETH_t1',
                              'dV_LTC_t1']
        df_cryp_t1 = df_cryp_t1.reset_index(drop=True)
        df_hourly = df_hourly.drop([0,1]).reset_index(drop=True)
        df_hourly = pd.concat((df_hourly, df_cryp_t0), axis=1)
        df_hourly = pd.concat((df_hourly, df_cryp_t1), axis=1)
        X_train = df_hourly.drop(columns=['pred_BCH', 'pred_BTC', 'pred_ETH', 'pred_LTC'])

        X_train = pd.get_dummies(X_train)
        y_BCH = model_BCH.predict(X_train)
        y_BTC = model_BTC.predict(X_train)
        y_ETH = model_ETH.predict(X_train)
        y_LTC = model_LTC.predict(X_train)
        y = [y_BCH, y_BTC, y_ETH, y_LTC]


        for i in asset_index:
            if y[i] == 'up':
                position_new[i] += 1
            elif y[i] == 'down':
                position_new[i] -= 1

        memory.hourly = memory.hourly.drop(0).reset_index(drop=True)



    return position_new, memory