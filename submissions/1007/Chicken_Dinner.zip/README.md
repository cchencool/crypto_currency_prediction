* Made small adjustment for next week.
    
    * Lower currency limit detetion.

    * Cancel the minimual-guarantee function. (due to the newest framework code update)

* Better strategy & modelling is undergoing, may apply in week 3.